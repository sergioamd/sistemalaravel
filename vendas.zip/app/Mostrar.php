<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mostrar extends Model
{
    protected $table = 'cobranca';
    protected $fillable = ['vendas'];


   

}
